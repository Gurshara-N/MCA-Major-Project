import os
import sqlite3
from datetime import datetime
from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv
from google.cloud import aiplatform, storage
from google.oauth2 import service_account


from langchain_google_vertexai import ChatVertexAI
from langchain.schema import SystemMessage, HumanMessage
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import ConversationalRetrievalChain
from langchain.docstore.document import Document

import certifi
os.environ["SSL_CERT_FILE"]      = certifi.where()
os.environ["REQUESTS_CA_BUNDLE"] = certifi.where()


load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

fallback_key = os.path.join(os.path.dirname(__file__),
                            "gen-lang-client-0658535528-df0c0eaf89e1.json")
SERVICE_ACCOUNT_JSON = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", fallback_key)

os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = SERVICE_ACCOUNT_JSON
SECRET_KEY = os.getenv("SECRET_KEY")


PROJECT_ID         = "gen-lang-client-0658535528"
LOCATION           = "us-central1"
MODEL_NAME         = "gemini-2.0-flash-001"
BUCKET_NAME        = "kelvinbucketk"
GCS_KNOWLEDGE_FILE = "creditcard_QA.txt"


aiplatform.init(project=PROJECT_ID, location=LOCATION)


def download_knowledge_from_gcs():
    storage_client = storage.Client.from_service_account_json(SERVICE_ACCOUNT_JSON)
    bucket = storage_client.bucket(BUCKET_NAME)
    blob   = bucket.blob(GCS_KNOWLEDGE_FILE)
    if not blob.exists():
        raise FileNotFoundError(f"{GCS_KNOWLEDGE_FILE} not found in gs://{BUCKET_NAME}")
    return blob.download_as_text(encoding="utf-8")

print("📥 Downloading knowledge base from GCS…")
kb_content = download_knowledge_from_gcs()
print("✅ Knowledge base loaded.")

splitter  = CharacterTextSplitter(separator="\n\n", chunk_size=1000, chunk_overlap=200)
chunks    = splitter.split_text(kb_content)
documents = [Document(page_content=c) for c in chunks]


embeddings  = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
vectorstore = FAISS.from_documents(documents, embeddings)


credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON)
llm = ChatVertexAI(
    project=PROJECT_ID,
    location=LOCATION,
    model_name=MODEL_NAME,
    credentials=credentials,
    api_key=GEMINI_API_KEY,
    max_output_tokens=180,
    temperature=0.25,
    top_p=0.95,
)
qa_chain = ConversationalRetrievalChain.from_llm(
    llm,
    retriever=vectorstore.as_retriever()
)



HISTORY_DB = os.path.join(os.path.dirname(__file__), "conversation_history.db")

def get_conversation_history(user_id, session_id):
    conn = sqlite3.connect(HISTORY_DB)
    c = conn.cursor()
    c.execute("""
      CREATE TABLE IF NOT EXISTS conversation_history (
        user_id TEXT, session_id TEXT,
        role TEXT, message TEXT, timestamp DATETIME
      )
    """)
    conn.commit()
    c.execute("""
      SELECT role, message FROM conversation_history
      WHERE user_id=? AND session_id=?
      ORDER BY timestamp
    """, (user_id, session_id))
    rows = c.fetchall()
    conn.close()

    history, temp = [], None
    for role, msg in rows:
        if role == "user":
            temp = msg
        elif role == "assistant" and temp:
            history.append((temp, msg))
            temp = None
    return history


def add_message_to_history(user_id, session_id, role, message):
    conn = sqlite3.connect(HISTORY_DB)
    c = conn.cursor()
    c.execute("""
      CREATE TABLE IF NOT EXISTS conversation_history (
        user_id TEXT, session_id TEXT,
        role TEXT, message TEXT, timestamp DATETIME
      )
    """)
    c.execute("""
      INSERT INTO conversation_history
      (user_id, session_id, role, message, timestamp)
      VALUES (?, ?, ?, ?, ?)
    """, (user_id, session_id, role, message, datetime.utcnow()))
    conn.commit()
    conn.close()

def reset_history_internal():
    conn = sqlite3.connect(HISTORY_DB)
    c = conn.cursor()
    c.execute("DROP TABLE IF EXISTS conversation_history")
    conn.commit()
    conn.close()
    return True




app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = SECRET_KEY or os.urandom(24)

@app.route('/')
def chat():
    reset_history_internal()
    return render_template('chat.html')

@app.route('/reset_history', methods=['GET'])
def reset_route():
    reset_history_internal()
    return jsonify({"status": "history reset"})

@app.route('/send', methods=['POST'])
def send_message():
    user_message = request.get_json(force=True).get("message")
    print("▶ Received question:", user_message)
    if not user_message:
        return jsonify({'response': 'No message received.'}), 400

    user_id, session_id = "unique_user_id", "unique_session_id"
    history = get_conversation_history(user_id, session_id)
    print("▶ Context history:", history)

    result = qa_chain({"question": user_message, "chat_history": history})
    answer = result.get("answer", "Sorry, I couldn't generate an answer.")
    print("▶ Generated answer:", answer)

    add_message_to_history(user_id, session_id, "user", user_message)
    add_message_to_history(user_id, session_id, "assistant", answer)

    return jsonify({'response': answer})

@app.route('/dialog_hist')
def dialog_hist():
    history = get_conversation_history("unique_user_id", "unique_session_id")
    return jsonify(history)

if __name__ == "__main__":
    app.run(debug=True, port=5000)